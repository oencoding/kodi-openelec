def run(hash,ump,referer=None):
	return {"url":"http://redmp3.cc/findfile/?id=%s&amp;v=2.1"%hash}