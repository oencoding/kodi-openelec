# service.subtitles.bsplayer
BSPlayer Subtitle Service for Kodi
